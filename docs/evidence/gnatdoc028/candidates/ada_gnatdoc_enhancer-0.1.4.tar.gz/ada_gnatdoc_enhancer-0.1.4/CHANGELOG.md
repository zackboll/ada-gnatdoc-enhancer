# Changelog

## 0.1.4 — prepared, not published (GNATDOC-028)

- Add opt-in static authored Ada fence and exact-source landing-example lexical
  highlighting, reusing the existing lexer and leaving native declaration behavior
  and all feature-off output unchanged.
- Add conservative public source/native-profile verified type and unique-callable
  example links, with shadowing/visibility guards and no arbitrary overload choice.
- Add strict Boolean guide options, scoped bundled CSS, exact landing-pre identity
  checks, mutation tests, official-wheel byte comparison and Chromium qualification.
- Include merged GNATDOC-027 without widening its lexical/overload scope.
- Advance CLI, module, distribution, archive audits and presentation metadata to
  0.1.4. Feature-off official v0.1.3 comparisons permit only the manifest version;
  preserve the historical v0.1.2-to-v0.1.3 comparator and acceptance tests.
- Distinguish the 1,462-record historical Core fixture from the 1,487-record
  current qualified Core consumer. No historical inventory is inflated.
- Candidate provenance uses `publication_authorized = false`. Final public assets
  require regeneration and qualification against the approved merged-main source.

## 0.1.3 — published baseline (GNATDOC-024 preparation history below)

- Add version-one opt-in offline documentation search over public, reconciled
  package/type/subtype/operation identities, source signatures/descriptions,
  distinct overloads, and approved published developer guide text.
- Share one search implementation across all three unchanged legacy routers;
  preserve canonical native declaration and authorized symbol routing.
- Validate the cache digest and separate destination allowlist at runtime;
  reconstruct all search output from approved inputs during verification.
- Add keyboard-accessible, bounded results and search-only mobile sizing with
  existing Core custom-theme compatibility. Label legacy filtering accurately.
- Retain the released-wheel failing reproduction, full actual Core fixture,
  Python mutation tests, Chromium qualification and hosted browser evidence.
- No published v0.1.2 asset, consumer configuration, tag or deployment changes.
- Without `[search]`, preserve the legacy navigation-link filter and all three
  native routers byte-for-byte. The intentional label change from "Search
  documentation" to "Filter navigation links" changes the API index HTML and
  its presentation-manifest hash; the manifest version also becomes `0.1.3`.
- Full search requires explicit `[search]` schema version 1, documentation mode,
  enabled navigation, static HTTP(S), JavaScript and SHA-256 Web Crypto (HTTPS
  or localhost). No remote search service, CDN or runtime dependency is needed.
  Native navigation remains usable without JavaScript or if index checks fail.
- Exclude private/internal and unsupported nested declarations, constants,
  quoted operators, unanchored instantiated members, arbitrary repository files
  and external dependency APIs. Source/native reconstruction and a separate
  browser destination allowlist authorize results, not a rehashed cache.
- Consumers must regenerate from pristine GNATdoc HTML 26.0.0 and independently
  qualify adoption; v0.1.2 manifests are not accepted as v0.1.3 manifests. Preserve
  Python 3.11–3.13, Apache-2.0, dependency-free core and exact optional guide pins.
- Preparation builds are not public release assets. Regenerate and audit final
  assets from the eventual approved merged-main commit; no publication authorized.

## 0.1.2 — release candidate (GNATDOC-020; not published)

- Include the reviewed GNATDOC-017 custom-theme, GNATDOC-018 stable external
  bookmark and GNATDOC-019 default-router restoration features described below.
  Themes and external stable bookmarks remain explicit hash-bound opt-ins;
  direct-fragment external links remain available, including without JavaScript.
- Default-router JavaScript intentionally changes relative to official v0.1.1,
  together with its presentation-manifest asset hash. Other profiles retain
  their output bytes except for `enhancer_version`. Against merged GNATDOC-019,
  only that version field may change in any profile.
- Synchronize active metadata, CLI, archive audits and manifest expectations to
  0.1.2. Retain the complete 653-test predecessor suite and add release controls,
  including previous-version rejection and wheel RECORD hash/size verification.
- Regenerate enhanced sites from pristine GNATdoc 26.0.0 native input; do not
  silently reuse v0.1.1 manifests. Stable links without publisher JavaScript
  provide native navigation, not guaranteed automatic declaration selection.
- Preserve Python 3.11–3.13, Apache-2.0, dependency-free core, optional renderer
  pins and all reviewed runtime bytes. No consumer migration or Pages approval,
  tag, GitHub release, PyPI upload or Alire submission is authorized.

## Historical merged development notes

## Unreleased — GNATDOC-019 (version remains 0.1.1)

- Restore default-router approved declaration visibility after matching iframe
  load/hash completion, already-loaded URL navigation, Back/Forward and `pageshow`.
  Use bounded animation-frame callbacks, rechecking current selection generation,
  pending navigation, exact document URL and complete document readiness.
- Preserve default URL/query/outer-fragment and History API semantics. Package-only
  selections do not scroll; unrelated user scroll does not trigger restoration.
  Stable-symbol and incoming-instance runtime assets remain byte-identical.
- Add negative-first authentic Chromium evidence and deterministic event-double
  regressions, including superseded callbacks and same-URL persisted scroll.
  Default publication JavaScript and its manifest hash change; consumers need
  independent requalification. Official v0.1.1 release assets remain unchanged.

## Unreleased — GNATDOC-018R1 (version remains 0.1.1)

- Add explicit hash-bound per-type external stable bookmarks for the independently
  qualified Core-v1 router. Emit canonical source-spelled package-plus-symbol
  URLs directly; retain ordinary external URL/query restrictions and default bytes.
- Reconstruct public source/native identities, the complete publisher symbol
  index, router identity and deployment/artifact evidence offline. Require `_top`;
  reject changed evidence, wrong-valid destinations and rehashed output mutations.
- Preserve direct-fragment JavaScript-disabled selection and document stable
  routing's native-navigation-only fallback without JavaScript. No publisher or
  consumer migration, release, tag, or runtime dependency change is authorized.

## Unreleased — GNATDOC-017 (version remains 0.1.1)

- Add paired opt-in `presentation.theme_css_source` / `theme_css_sha256` for
  exact, independently approved consumer CSS bytes at the existing theme path.
  Keep default assets, HTML, navigation and presentation manifest bytes unchanged.
- Verify source/hash/configuration identity during enhancement and independent
  reconstruction; reject symlinks, traversal, unsafe CSS resources/execution,
  unsupported encoding and changed output. Strengthen the shared CSS rejection
  policy for string-form resource functions without rewriting approved bytes.
- Add focused mutation/compatibility regressions and a pinned Core presentation
  pilot. Existing authored/summary functionality is reused, not reimplemented.
  This development work does not publish a release or approve consumer deployment.

## 0.1.1 — planned maintenance release (GNATDOC-015; not yet published)

- Add opt-in `[presentation].external_type_target = "_top"` for already
  source-verified external type links. Omitted configuration preserves v0.1.0
  navigation and output exactly except for version-bound presentation metadata;
  local, generic-instance, guide and native navigation is unchanged.
- Extend strict canonical snippet reconstruction and adversarial publication
  tests; qualify exact top-level browser navigation against Imgproc PR #81's
  independent 586-occurrence / 14-type evidence without changing that consumer.
- Keep strict source/config-derived link reconstruction, external-host authorization
  and source/native declaration identity restrictions. No default script or asset
  changes, new dependency or Python-version requirement.
- Include the independently reviewed GNATDOC-014 browser/security qualification.
  Imgproc's migration motivates top-level navigation; its Core policy approval,
  authored-site parity, full production browser/security checks and Pages deployment
  remain separate consumer requirements. PR #81 is not modified or approved here.
- Synchronize active version authorities to 0.1.1 and prepare independent archive,
  installed-package, compatibility and browser requalification. Publication requires
  a later independently authorized task; the published v0.1.0 tag/assets stay intact.

## 0.1.0 — release candidate (GNATDOC-012R2; not yet published)

- Consolidate merged GNATDOC-001–011: fail-closed source/native qualification,
  navigation, highlighting, conservative local/external type links, 25 optional
  generic summaries, authored guides/portals, subtype/current-package links,
  page metadata and native-symbol bookmarks.
- Include R1's separately authorized 242 incoming instance references and R2's
  incoming-router canonical query reconstruction.
- Incorporate independently reviewed GNATDOC-011R3: clear inherited query keys
  and unsupported outer fragments before reconstructing canonical symbol-only
  navigation. Preserve default and incoming-instance router bytes and all 18 R3
  regressions. R2 intentionally did not fix the symbol-only defect.
- Supersede the original 543-test release qualification with a distinct corrective
  campaign retaining all 561 tests plus three independently justified malformed
  wheel controls (564 total). Reject Unix symlink/device/FIFO/socket members in
  wheel archives; preserve all historical evidence and identities.
- Synchronize module, distribution and CLI versions; adopt SPDX Apache-2.0
  metadata with LICENSE; preserve Python >=3.11, optional guide pins and the
  dependency-free core.
- Independently qualify wheel and extracted-sdist rebuilt wheel; keep complete
  test inputs without bundling large historical evidence.
- Document consumer boundaries, upgrades, release stop conditions and the later
  GNATDOC-013 procedure. No tagging, publication or consumer adoption.

## Historical pre-release entries

## Unreleased — GNATDOC-009B

- Link exact two-identifier current-package public type/subtype marks with
  source-owned native destinations and conservative actual-short-prefix
  shadowing checks. No external fallback or arbitrary short-owner inference.
  Add authentic nine-occurrence MEL regressions and independent qualification.

## Unreleased — GNATDOC-010

- Source-verified document metadata: every generated API page gets `lang="en"`,
  an explicit head, a UTF-8 charset and a title from its verified package (or
  `API Reference`) and the project name; Markdown guides get their site-map
  label as title, which must equal the H1. Author pages must carry their own
  metadata. See `docs/html-page-metadata.md`.
- Reconciled with GNATDOC-009A ordinary subtype-base links (merged `main`
  `426f388`); the combined behavior is requalified on every real consumer,
  including the current Geometry `Contour` → Core `OpenCV.Point_Array` link.

## 0.1.0.dev0 — bootstrap

- Packaging, CLI, offline enhancement and verification, source inventories, presentation assets.
- Four sample project profiles and offline regression fixtures.
- No compatibility or distribution release claimed.
