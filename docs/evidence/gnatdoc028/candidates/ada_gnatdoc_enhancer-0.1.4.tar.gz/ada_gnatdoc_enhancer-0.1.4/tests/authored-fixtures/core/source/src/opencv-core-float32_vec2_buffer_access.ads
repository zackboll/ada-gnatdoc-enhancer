with OpenCV.Core.Float32_Vec2;

--  Zero-copy, callback-scoped access to the complete pixel buffer of a
--  continuous two-channel Float32 (CV_32FC2) Mat of any dimension count.
--  The view aliases native storage and is valid only during the callback.
--  Every operation validates the Mat's depth, channel count and continuity
--  and raises OpenCV_Error on any mismatch, before the callback is invoked.

package OpenCV.Core.Float32_Vec2_Buffer_Access is
   --  The flat pixel buffer of a Mat: one Float32_Vec2.Vector per Mat
   --  element, in OpenCV element order with the final dimension varying
   --  fastest. The callbacks pass arrays whose bounds are
   --  0 .. Natural (Image.Total) - 1.
   type Buffer_Array is array (Natural range <>) of Float32_Vec2.Vector;

   --  Callback-scoped zero-copy borrow of a continuous Float32 C2 Mat of
   --  any dimension count; genuine N-D Mats are supported. Data is one
   --  flat zero-based array, Data'Length = Natural (Image.Total), in
   --  OpenCV element order with the final dimension varying fastest; for
   --  a 2-D Mat, Data (Row * Image.Columns + Column) is (Row, Column).
   --  Each element is one complete C2 element; channels are never
   --  flattened. Non-continuous Mats (gapped Regions or Slices) raise
   --  OpenCV_Error before Process runs. A shallow Mat lease keeps the
   --  storage alive (memory lifetime, not synchronization); writes are
   --  immediately visible. References must not escape the callback.
   --  @param Image A continuous Float32 Mat with exactly two channels.
   --  @param Process Callback that receives the borrowed buffer. Data is
   --  valid only during the call and must not be retained.
   --  @exception OpenCV_Error Raised, before Process is invoked, when Image
   --  is not a Float32 two-channel Mat or is nonempty and not continuous,
   --  or has more elements than Natural'Last.
   procedure With_Read_Only_Buffer
     (Image   : Mat;
      Process : not null access procedure (Data : aliased Buffer_Array));

   --  As With_Read_Only_Buffer, except Process receives an in-out view;
   --  writes through Data mutate the actual Mat storage immediately.
   --  @param Image A continuous Float32 Mat with exactly two channels.
   --  @param Process Callback that receives the borrowed buffer for reading
   --  and writing. Data is valid only during the call and must not be
   --  retained.
   --  @exception OpenCV_Error Raised, before Process is invoked, when Image
   --  is not a Float32 two-channel Mat or is nonempty and not continuous,
   --  or has more elements than Natural'Last.
   procedure With_Writable_Buffer
     (Image   : in out Mat;
      Process :
        not null access procedure (Data : aliased in out Buffer_Array));
end OpenCV.Core.Float32_Vec2_Buffer_Access;
